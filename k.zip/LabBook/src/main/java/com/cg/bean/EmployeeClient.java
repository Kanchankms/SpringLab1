package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class EmployeeClient {

	public static void main(String[] args)
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("employee.xml");
		Employee employee = (Employee) ctx.getBean("employee");
		
		System.out.println("Employee Info");
		System.out.println("Employee Id: "+employee.getEmployeeId());
		System.out.println("Employee Name: "+employee.getEmployeeName());
		System.out.println("Employee Age: "+employee.getAge());
		System.out.println("Employee Salary: "+employee.getSalary());
		System.out.println("Employee BussinessUnit: "+employee.getBusinessUnit());
		
			
	}

}
